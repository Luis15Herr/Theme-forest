<?php

// Register action/filter callbacks

add_action( 'after_setup_theme', 'boldthemes_register_menus' );
add_action( 'wp_enqueue_scripts', 'boldthemes_enqueue_scripts_styles' );
add_action( 'tgmpa_register', 'boldthemes_register_plugins' );
add_action( 'wp_enqueue_scripts', 'boldthemes_load_fonts' );

add_filter( 'boldthemes_extra_class', 'craft_extra_class' );
add_filter( 'boldthemes_header_headline_size', 'boldthemes_header_headline_size' );

// callbacks

/**
 * Register navigation menus
 */
if ( ! function_exists( 'boldthemes_register_menus' ) ) {
	function boldthemes_register_menus() {
		register_nav_menus( array (
			'primary' => esc_html__( 'Primary Menu', 'craftportfolio' ),
			'footer'  => esc_html__( 'Footer Menu', 'craftportfolio' )
		));
	}
}

/**
 * Enqueue scripts and styles
 */
if ( ! function_exists( 'boldthemes_enqueue_scripts_styles' ) ) {
	function boldthemes_enqueue_scripts_styles() {

		BoldThemesFramework::$crush_vars_def = array( 'accentColor', 'alternateColor', 'bodyFont', 'menuFont', 'headingFont', 'headingSuperTitleFont', 'headingSubTitleFont', 'logoHeight' );
		
		// Create override file without local settings

		if ( function_exists( 'boldthemes_csscrush_file' ) ) {
			boldthemes_csscrush_file( get_stylesheet_directory() . '/style.css', array( 'source_map' => true, 'minify' => false, 'output_file' => 'style.crush', 'formatter' => 'block', 'boilerplate' => false, 'plugins' => array( 'loop', 'ease' ) ) );
			boldthemes_csscrush_file( get_stylesheet_directory() . '/style.css', array( 'source_map' => true, 'minify' => true, 'output_file' => 'style.crush.min', 'boilerplate' => false,  'plugins' => array( 'loop', 'ease' ) ) );
		}

		//custom accent color and font style

		$accent_color = boldthemes_get_option( 'accent_color' );
		$alternate_color = boldthemes_get_option( 'alternate_color' );
		$body_font = urldecode( boldthemes_get_option( 'body_font' ) );
		$menu_font = urldecode( boldthemes_get_option( 'menu_font' ) );
		$heading_font = urldecode( boldthemes_get_option( 'heading_font' ) );
		$heading_supertitle_font = urldecode( boldthemes_get_option( 'heading_supertitle_font' ) );
		$heading_subtitle_font = urldecode( boldthemes_get_option( 'heading_subtitle_font' ) );
		$logo_height = urldecode( boldthemes_get_option( 'logo_height' ) );

		if ( $accent_color != '' ) {
			BoldThemesFramework::$crush_vars['accentColor'] = $accent_color;
		}

		if ( $alternate_color != '' ) {
			BoldThemesFramework::$crush_vars['alternateColor'] = $alternate_color;
		}

		if ( $body_font != 'no_change' ) {
			BoldThemesFramework::$crush_vars['bodyFont'] = $body_font;
		}

		if ( $menu_font != 'no_change' ) {
			BoldThemesFramework::$crush_vars['menuFont'] = $menu_font;
		}

		if ( $heading_font != 'no_change' ) {
			BoldThemesFramework::$crush_vars['headingFont'] = $heading_font;
		}

		if ( $heading_supertitle_font != 'no_change' ) {
			BoldThemesFramework::$crush_vars['headingSuperTitleFont'] = $heading_supertitle_font;
		}

		if ( $heading_subtitle_font != 'no_change' ) {
			BoldThemesFramework::$crush_vars['headingSubTitleFont'] = $heading_subtitle_font;
		}
		
		if ( $logo_height != '' ) {
			BoldThemesFramework::$crush_vars['logoHeight'] = $logo_height;
		}

		// custom theme css
		wp_enqueue_style( 'boldthemes_style_css', get_template_directory_uri() . '/style.crush.css', array(), false );
		// wp_enqueue_style( 'boldthemes_style_css', get_template_directory_uri() . '/style.crush.min.css', array(), false );
		
		// custom buggyfill css
		wp_enqueue_style( 'boldthemes_buggyfill_css', get_template_directory_uri() . '/css/viewport-buggyfill.css', array(), false );
		// custom magnific popup css
		wp_enqueue_style( 'boldthemes_magnific-popup_css', get_template_directory_uri() . '/css/magnific-popup.css', array(), false );
		// custom ie9 css
		wp_enqueue_style( 'boldthemes_ie9_css', get_template_directory_uri() . '/css/ie9.css', array(), false );
		
		// third-party js
		wp_enqueue_script( 'viewport-units-buggyfill', get_template_directory_uri() . '/framework/js/viewport-units-buggyfill.js', array( 'jquery' ), '', false );
		wp_enqueue_script( 'slick.min', get_template_directory_uri() . '/framework/js/slick.min.js', array( 'jquery' ), '', false );
		wp_enqueue_script( 'jquery.magnific-popup.min', get_template_directory_uri() . '/framework/js/jquery.magnific-popup.min.js', array( 'jquery' ), '', false );
		if ( ! wp_is_mobile() ) wp_enqueue_script( 'iscroll', get_template_directory_uri() . '/framework/js/iscroll.js', array( 'jquery' ), '', false );
		wp_enqueue_script( 'fancySelect', get_template_directory_uri() . '/framework/js/fancySelect.js', array( 'jquery' ), '', false );			
		wp_enqueue_script( 'html5shiv.min', get_template_directory_uri() . '/framework/js/html5shiv.min.js', array(), false );
		wp_enqueue_script( 'respond.min', get_template_directory_uri() . '/framework/js/respond.min.js', array(), false );
		
		// custom modernizr js
		wp_enqueue_script( 'boldthemes_modernizr_js', get_template_directory_uri() . '/framework/js/modernizr.custom.js', array( 'jquery' ), '', false );
		// custom buggyfill js
		wp_enqueue_script( 'boldthemes_buggyfill_hacks_js', get_template_directory_uri() . '/framework/js/viewport-units-buggyfill.hacks.js', array( 'jquery' ), '', false );
		wp_add_inline_script( 'boldthemes_buggyfill_hacks_js', boldthemes_buggyfill_function() );
		// custom miscellaneous js
		wp_enqueue_script( 'boldthemes_header_js', get_template_directory_uri() . '/framework/js/header.misc.js', array( 'jquery' ), '', false );
		// custom tile hover effect js			
		wp_enqueue_script( 'boldthemes_misc_js', get_template_directory_uri() . '/framework/js/misc.js', array( 'jquery' ), '', true );
		// custom header related js
		wp_enqueue_script( 'boldthemes_dirhover_js', get_template_directory_uri() . '/framework/js/dir.hover.js', array( 'jquery' ), '', false );
		wp_add_inline_script( 'boldthemes_header_js', boldthemes_set_global_uri(), 'before' );
		// custom slider js
		wp_enqueue_script( 'boldthemes_sliders_js', get_template_directory_uri() . '/framework/js/sliders.js', array( 'jquery' ), '', false );			

		// dequeue cost calculator plugin style
		wp_dequeue_style( 'bt_cc_style' );
		
		if ( file_exists( get_template_directory() . '/css_override.php' ) ) {
			require_once( get_template_directory() . '/css_override.php' );
			if ( count( BoldThemesFramework::$crush_vars ) > 0 ) wp_add_inline_style( 'boldthemes_style_css', $css_override );
		}
		
		if ( boldthemes_get_option( 'custom_css' ) != '' ) {
			wp_add_inline_style( 'boldthemes_style_css', boldthemes_get_option( 'custom_css' ) );
		}

		if ( boldthemes_get_option( 'custom_js_top' ) != '' ) {
			wp_add_inline_script( 'boldthemes_modernizr_js', boldthemes_get_option( 'custom_js_top' ) );
		}

		if ( boldthemes_get_option( 'custom_js_bottom' ) != '' ) {
			wp_add_inline_script( 'boldthemes_misc_js', boldthemes_get_option( 'custom_js_bottom' ) );
		}		
		
	}
}

/**
 * Register the required plugins for this theme
 */
if ( ! function_exists( 'boldthemes_register_plugins' ) ) {
	function boldthemes_register_plugins() {

		$plugins = array(
	 
			array(
				'name'               => esc_html__( 'CraftPortfolio', 'craftportfolio' ), // The plugin name.
				'slug'               => 'craftportfolio', // The plugin slug (typically the folder name).
				'source'             => get_template_directory() . '/plugins/craftportfolio.zip', // The plugin source.
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'version'            => '1.0.7', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => true, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
				'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			),
			array(
				'name'               => esc_html__( 'Cost Calculator', 'craftportfolio' ), // The plugin name.
				'slug'               => 'bt' . '_cost_calculator', // The plugin slug (typically the folder name).
				'source'             => get_template_directory() . '/plugins/' . 'bt' . '_cost_calculator.zip', // The plugin source.
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'version'            => '1.1.6', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => true, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
				'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			),
			array(
				'name'               => esc_html__( 'Bold Builder', 'craftportfolio' ), // The plugin name.
				'slug'               => 'bold-page-builder', // The plugin slug (typically the folder name).
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => true, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			),
			array(
				'name'               => esc_html__( 'BoldThemes WordPress Importer', 'craftportfolio' ), // The plugin name.
				'slug'               => 'bt' . '_wordpress_importer', // The plugin slug (typically the folder name).
				'source'             => get_template_directory() . '/plugins/' . 'bt' . '_wordpress_importer.zip', // The plugin source.
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'version'            => '1.0.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => true, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
				'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			),
			array(
				'name'               => esc_html__( 'Meta Box', 'craftportfolio' ), // The plugin name.
				'slug'               => 'meta-box', // The plugin slug (typically the folder name).
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			),
			array(
				'name'               => esc_html__( 'Contact Form 7', 'craftportfolio' ), // The plugin name.
				'slug'               => 'contact-form-7', // The plugin slug (typically the folder name).
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			),
			array(
				'name'               => esc_html__( 'WooSidebars', 'craftportfolio' ), // The plugin name.
				'slug'               => 'woosidebars', // The plugin slug (typically the folder name).
				'required'           => true, // If false, the plugin is only 'recommended' instead of required.
				'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
				'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			)

		);
	 
		$config = array(
			'default_path' => '',                      // Default absolute path to pre-packaged plugins.
			'menu'         => 'tgmpa-install-plugins', // Menu slug.
			'has_notices'  => true,                    // Show admin notices or not.
			'dismissable'  => false,                    // If false, a user cannot dismiss the nag message.
			'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
			'is_automatic' => true,                   // Automatically activate plugins after installation or not.
			'message'      => '',                      // Message to output right before the plugins table.
			'strings'      => array(
				'page_title'                      => esc_html__( 'Install Required Plugins', 'craftportfolio' ),
				'menu_title'                      => esc_html__( 'Install Plugins', 'craftportfolio' ),
				'installing'                      => esc_html__( 'Installing Plugin: %s', 'craftportfolio' ), // %s = plugin name.
				'oops'                            => esc_html__( 'Something went wrong with the plugin API.', 'craftportfolio' ),
				'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'craftportfolio' ), // %1$s = plugin name(s).
				'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'craftportfolio' ), // %1$s = plugin name(s).
				'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'craftportfolio' ),
				'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins', 'craftportfolio' ),
				'return'                          => esc_html__( 'Return to Required Plugins Installer', 'craftportfolio' ),
				'plugin_activated'                => esc_html__( 'Plugin activated successfully.', 'craftportfolio' ),
				'complete'                        => esc_html__( 'All plugins installed and activated successfully. %s', 'craftportfolio' ), // %s = dashboard link.
				'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
			)
		);
	 
		tgmpa( $plugins, $config );
	 
	}
}

/**
 * Loads custom Google Fonts
 */
if ( ! function_exists( 'boldthemes_load_fonts' ) ) {
	function boldthemes_load_fonts() {
		$body_font = urldecode( boldthemes_get_option( 'body_font' ) );
		$heading_font = urldecode( boldthemes_get_option( 'heading_font' ) );
		$menu_font = urldecode( boldthemes_get_option( 'menu_font' ) );
		$heading_subtitle_font = urldecode( boldthemes_get_option( 'heading_subtitle_font' ) );
		$heading_supertitle_font = urldecode( boldthemes_get_option( 'heading_supertitle_font' ) );
		
		$font_families = array();
		
		if ( $body_font != 'no_change' ) {
			$font_families[] = $body_font . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
		} else {
			$body_font_state = _x( 'on', 'Montserrat font: on or off', 'craftportfolio' );
			if ( 'off' !== $body_font_state ) {
				$font_families[] = 'Montserrat' . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
			}
		}
		
		if ( $heading_font != 'no_change' ) {
			$font_families[] = $heading_font . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
		} else {
			$heading_font_state = _x( 'on', 'Montserrat font: on or off', 'craftportfolio' );
			if ( 'off' !== $heading_font_state ) {
				$font_families[] = 'Montserrat' . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
			}
		}
		
		if ( $menu_font != 'no_change' ) {
			$font_families[] = $menu_font . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
		} else {
			$menu_font_state = _x( 'on', 'Montserrat font: on or off', 'craftportfolio' );
			if ( 'off' !== $menu_font_state ) {
				$font_families[] = 'Montserrat' . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
			}
		}

		if ( $heading_subtitle_font != 'no_change' ) {
			$font_families[] = $heading_subtitle_font . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
		} else {
			$heading_subtitle_font_state = _x( 'on', 'Montserrat font: on or off', 'craftportfolio' );
			if ( 'off' !== $heading_subtitle_font_state ) {
				$font_families[] = 'Montserrat' . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
			}
		}

		if ( $heading_supertitle_font != 'no_change' ) {
			$font_families[] = $heading_supertitle_font . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
		} else {
			$heading_supertitle_font_state = _x( 'on', 'Montserrat font: on or off', 'craftportfolio' );
			if ( 'off' !== $heading_supertitle_font_state ) {
				$font_families[] = 'Montserrat' . ':100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic';
			}
		}

		if ( count( $font_families ) > 0 ) {
			$query_args = array(
				'family' => urlencode( implode( '|', $font_families ) ),
				'subset' => urlencode( 'latin,latin-ext' ),
			);
			$font_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
			wp_enqueue_style( 'boldthemes_fonts', $font_url, array(), '1.0.0' );
		}
	}
}

/**
 * Extra classes
 */
if ( ! function_exists( 'craft_extra_class' ) ) {
	function craft_extra_class( $extra_class ) {
		if ( boldthemes_get_option( 'buttons_shape' ) == "no_change" ) {
			$extra_class[] = 'btSquareButtons' ;
		}
		return $extra_class;
	}
}

/**
 * Header headline size
 */
if ( ! function_exists( 'boldthemes_header_headline_size' ) ) {
	function boldthemes_header_headline_size( $size ) {
		return 'extralarge';
	}
}

// set content width
if ( ! isset( $content_width ) ) {
	$content_width = 1200;
}

require_once( get_template_directory() . '/php/before_framework.php' );

require_once( get_template_directory() . '/framework/framework.php' );

require_once( get_template_directory() . '/php/after_framework.php' );