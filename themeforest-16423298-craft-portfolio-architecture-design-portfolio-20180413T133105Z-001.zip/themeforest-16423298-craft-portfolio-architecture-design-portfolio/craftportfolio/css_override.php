<?php
if ( class_exists( 'BoldThemesFramework' ) && isset( BoldThemesFramework::$crush_vars ) ) {
	$boldthemes_crush_vars = BoldThemesFramework::$crush_vars;
}
if ( class_exists( 'BoldThemesFramework' ) && isset( BoldThemesFramework::$crush_vars_def ) ) {
	$boldthemes_crush_vars_def = BoldThemesFramework::$crush_vars_def;
}
if ( isset( $boldthemes_crush_vars['headingFont'] ) ) {
	$headingFont = $boldthemes_crush_vars['headingFont'];
} else {
	$headingFont = "Montserrat";
}
if ( isset( $boldthemes_crush_vars['headingSuperTitleFont'] ) ) {
	$headingSuperTitleFont = $boldthemes_crush_vars['headingSuperTitleFont'];
} else {
	$headingSuperTitleFont = "Montserrat";
}
if ( isset( $boldthemes_crush_vars['headingSubTitleFont'] ) ) {
	$headingSubTitleFont = $boldthemes_crush_vars['headingSubTitleFont'];
} else {
	$headingSubTitleFont = "Montserrat";
}
if ( isset( $boldthemes_crush_vars['menuFont'] ) ) {
	$menuFont = $boldthemes_crush_vars['menuFont'];
} else {
	$menuFont = "Montserrat";
}
if ( isset( $boldthemes_crush_vars['bodyFont'] ) ) {
	$bodyFont = $boldthemes_crush_vars['bodyFont'];
} else {
	$bodyFont = "Montserrat";
}
if ( isset( $boldthemes_crush_vars['accentColor'] ) ) {
	$accentColor = $boldthemes_crush_vars['accentColor'];
} else {
	$accentColor = "#5cc8ec";
}
$accentColorDark = CssCrush\fn__l_adjust( $accentColor." -54" );$accentColorLight = CssCrush\fn__a_adjust( $accentColor." -30" );if ( isset( $boldthemes_crush_vars['alternateColor'] ) ) {
	$alternateColor = $boldthemes_crush_vars['alternateColor'];
} else {
	$alternateColor = "#a0b751";
}
if ( isset( $boldthemes_crush_vars['logoHeight'] ) ) {
	$logoHeight = $boldthemes_crush_vars['logoHeight'];
} else {
	$logoHeight = "50";
}
$css_override = wp_kses("input:not([type='checkbox']):not([type='radio']):not([type='submit']):focus,textarea:not([type='checkbox']):not([type='radio']):focus{-webkit-box-shadow:0 0 4px 0 {$accentColor};box-shadow:0 0 4px 0 {$accentColor};}
a:hover{color:{$accentColor};}
select,input{font-family:{$bodyFont};}
body{font-family:\"{$bodyFont}\",Arial,sans-serif;}
h1,h2,h3,h4,h5,h6{font-family:\"{$headingFont}\";}
.btContentHolder table thead th{background-color:{$accentColor};}
.btAccentColorBackground{background-color:{$accentColor}!important;}
.btLightSkin .btText a,.btDarkSkin .btLightSkin .btText a,.btDarkSkin .btText a,.btLightSkin .btDarkSkin .btText a{color:{$accentColor};}
.btPreloader .animation .preloaderLogo{height:{$logoHeight}px;}
.menuPort{font-family:\"{$menuFont}\";}
.menuPort nav ul li a:hover{color:{$accentColor}!important;}
.menuPort nav>ul>li>a{line-height:{$logoHeight}px;}
.btTextLogo{line-height:{$logoHeight}px;}
.btLogoArea .logo img{height:{$logoHeight}px;}
.btHorizontalMenuTrigger{line-height:{$logoHeight}px;}
.btMenuHorizontal .menuPort nav>ul>li>ul li.current-menu-ancestor>a,.btMenuHorizontal .menuPort nav>ul>li>ul li.current-menu-item>a{color:{$accentColor}!important;}
body.btMenuHorizontal .subToggler{line-height:{$logoHeight}px;}
.btMenuHorizontal .topBarInMenu{height:{$logoHeight}px;}
.btVerticalMenuTrigger{line-height:{$logoHeight}px;}
body.btMenuVertical>.menuPort .btCloseVertical:before:hover{color:{$accentColor};}
@media (min-width:1400px){.btMenuVerticalOn .btVerticalMenuTrigger .btIco a:before{color:{$accentColor}!important;}
}a.btIconWidget:hover{color:{$accentColor}!important;}
.btSpecialHeaderIcon .btIco .btIcoHolder:before,.btSpecialHeaderIcon .btIconWidgetTitle,.btSpecialHeaderIcon .btIconWidgetText{color:{$accentColor}!important;}
.btMenuHorizontal .topBarInLogoArea{height:{$logoHeight}px;}
.btMenuHorizontal .topBarInLogoArea .topBarInLogoAreaCell{border:0 solid {$accentColor};}
.topBar .widget_search button,.topBarInMenu .widget_search button{background:{$accentColor};}
.topBar .widget_search button:before,.topBarInMenu .widget_search button:before{color:{$accentColor};}
.topBar .widget_search button:hover,.topBarInMenu .widget_search button:hover{background:{$accentColorDark};}
.btSearchInner.btFromTopBox{background:{$accentColorDark};}
.btSearchInner.btFromTopBox form button:hover:before{color:{$accentColor};}
.btMediaBox.btQuote,.btMediaBox.btLink{background-color:{$accentColor};}
.btArticleListItem .headline a:hover{color:{$accentColor};}
.commentTxt p.edit-link a:hover,.commentTxt p.reply a:hover{color:{$accentColor};}
.btBox .ppTxt .headline a:hover,.btCustomMenu .ppTxt .headline a:hover,.btCartWidget .ppTxt .headline a:hover{color:{$accentColor};}
.btBox.widget_calendar table caption{background:{$accentColor};font-family:\"{$headingFont}\";}
.btBox.widget_rss li a.rsswidget{font-family:\"{$headingFont}\";}
.btBox.widget_rss li cite:before{color:{$accentColor};}
.btBox .btSearch button:hover,form.woocommerce-product-search button:hover{background:{$accentColor}!important;border-color:{$accentColor}!important;}
form.wpcf7-form .wpcf7-submit{background-color:{$accentColor};}
.fancy-select .trigger.open{color:{$accentColor};}
.fancy-select ul.options>li:hover{color:{$accentColor};}
.widget_shopping_cart .widget_shopping_cart_content .mini_cart_item .ppRemove a.remove:hover:before{background-color:{$accentColor};}
.widget_price_filter .ui-slider .ui-slider-handle{background-color:{$accentColor};}
.widget_layered_nav ul li.chosen a:hover:before,.widget_layered_nav ul li a:hover:before,.widget_layered_nav_filters ul li.chosen a:hover:before,.widget_layered_nav_filters ul li a:hover:before{background-color:{$accentColor};}
.btBox .tagcloud a:hover,.btTags ul a:hover{background:{$accentColor};}
.header .btSubTitle .btArticleCategories a:not(:first-child):before,.header .btSuperTitle .btArticleCategories a:not(:first-child):before{background-color:{$accentColor};}
.post-password-form input[type=\"submit\"]{background:{$accentColor};font-family:\"{$headingFont}\";}
.btPagination{font-family:\"{$headingFont}\";}
.btPagination .paging a:hover:after{border-color:{$accentColor};}
.comment-respond .btnOutline button[type=\"submit\"]{font-family:\"{$headingFont}\";}
a#cancel-comment-reply-link:hover{color:{$accentColor};}
span.btHighlight{background-color:{$accentColor};}
.menuPort .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetIcon span.cart-contents,.topTools .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetIcon span.cart-contents,.topBarInLogoArea .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetIcon span.cart-contents{background-color:{$alternateColor};font:normal 10px/1 {$headingFont};}
.menuPort .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetIcon span.btIcoHolder:hover:before,.topTools .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetIcon span.btIcoHolder:hover:before,.topBarInLogoArea .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetIcon span.btIcoHolder:hover:before{color:{$accentColor};}
.btMenuVertical .menuPort .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetInnerContent .verticalMenuCartToggler,.btMenuVertical .topTools .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetInnerContent .verticalMenuCartToggler,.btMenuVertical .topBarInLogoArea .widget_shopping_cart .widget_shopping_cart_content .btCartWidgetInnerContent .verticalMenuCartToggler{background-color:{$accentColor};}
.btIco.btIcoFilledType.btIcoAccentColor .btIcoHolder:before,.btIco.btIcoOutlineType.btIcoAccentColor:hover .btIcoHolder:before{-webkit-box-shadow:0 0 0 1em {$accentColor} inset;box-shadow:0 0 0 1em {$accentColor} inset;}
.btIco.btIcoFilledType.btIcoAccentColor:hover .btIcoHolder:before,.btIco.btIcoOutlineType.btIcoAccentColor .btIcoHolder:before{-webkit-box-shadow:0 0 0 2px {$accentColor} inset;box-shadow:0 0 0 2px {$accentColor} inset;color:{$accentColor};}
.btIco.btIcoFilledType.btIcoAlternateColor .btIcoHolder:before,.btIco.btIcoOutlineType.btIcoAlternateColor:hover .btIcoHolder:before{-webkit-box-shadow:0 0 0 1em {$alternateColor} inset;box-shadow:0 0 0 1em {$alternateColor} inset;}
.btIco.btIcoFilledType.btIcoAlternateColor:hover .btIcoHolder:before,.btIco.btIcoOutlineType.btIcoAlternateColor .btIcoHolder:before{-webkit-box-shadow:0 0 0 2px {$alternateColor} inset;box-shadow:0 0 0 2px {$alternateColor} inset;color:{$alternateColor};}
.btLightSkin .btIco.btIcoDefaultType.btIcoAccentColor .btIcoHolder:before,.btLightSkin .btIco.btIcoDefaultType.btIcoDefaultColor:hover .btIcoHolder:before,.btDarkSkin .btLightSkin .btIco.btIcoDefaultType.btIcoAccentColor .btIcoHolder:before,.btDarkSkin .btLightSkin .btIco.btIcoDefaultType.btIcoDefaultColor:hover .btIcoHolder:before,.btDarkSkin .btIco.btIcoDefaultType.btIcoAccentColor .btIcoHolder:before,.btDarkSkin .btIco.btIcoDefaultType.btIcoDefaultColor:hover .btIcoHolder:before,.btLightSkin .btDarkSkin .btIco.btIcoDefaultType.btIcoAccentColor .btIcoHolder:before,.btLightSkin .btDarkSkin .btIco.btIcoDefaultType.btIcoDefaultColor:hover .btIcoHolder:before{color:{$accentColor};}
.btLightSkin .btIco.btIcoDefaultType.btIcoAlternateColor .btIcoHolder:before,.btDarkSkin .btLightSkin .btIco.btIcoDefaultType.btIcoAlternateColor .btIcoHolder:before,.btDarkSkin .btIco.btIcoDefaultType.btIcoAlternateColor .btIcoHolder:before,.btLightSkin .btDarkSkin .btIco.btIcoDefaultType.btIcoAlternateColor .btIcoHolder:before{color:{$alternateColor};}
.btIcoAccentColor span{color:{$accentColor};}
.btIcoDefaultColor:hover span{color:{$accentColor};}
.btBtn.btnOutlineStyle.btnAccentColor.btnIco.btnRightPosition .btIco{border-left:2px solid {$accentColor};}
.btBtn.btnOutlineStyle.btnAlternateColor.btnIco.btnRightPosition .btIco{border-left:2px solid {$alternateColor};}
.btBtn.btnOutlineStyle.btnAccentColor.btnIco.btnLeftPosition .btIco{border-right:2px solid {$accentColor};}
.btBtn.btnOutlineStyle.btnAlternateColor.btnIco.btnLeftPosition .btIco{border-right:2px solid {$alternateColor};}
.btnFilledStyle.btnAccentColor,.btnOutlineStyle.btnAccentColor:hover{background-color:{$accentColor};border:2px solid {$accentColor};}
.btnOutlineStyle.btnAccentColor,.btnFilledStyle.btnAccentColor:hover{border:2px solid {$accentColor};color:{$accentColor};}
.btnOutlineStyle.btnAccentColor span,.btnFilledStyle.btnAccentColor:hover span,.btnOutlineStyle.btnAccentColor span:before,.btnFilledStyle.btnAccentColor:hover span:before,.btnOutlineStyle.btnAccentColor a,.btnFilledStyle.btnAccentColor:hover a,.btnOutlineStyle.btnAccentColor .btIco a:before,.btnFilledStyle.btnAccentColor:hover .btIco a:before,.btnOutlineStyle.btnAccentColor button,.btnFilledStyle.btnAccentColor:hover button{color:{$accentColor}!important;}
.btnBorderlessStyle.btnAccentColor span,.btnBorderlessStyle.btnNormalColor:hover span,.btnBorderlessStyle.btnAccentColor span:before,.btnBorderlessStyle.btnNormalColor:hover span:before,.btnBorderlessStyle.btnAccentColor a,.btnBorderlessStyle.btnNormalColor:hover a,.btnBorderlessStyle.btnAccentColor .btIco a:before,.btnBorderlessStyle.btnNormalColor:hover .btIco a:before,.btnBorderlessStyle.btnAccentColor button,.btnBorderlessStyle.btnNormalColor:hover button{color:{$accentColor};}
.btnFilledStyle.btnAlternateColor,.btnOutlineStyle.btnAlternateColor:hover{background-color:{$alternateColor};border:2px solid {$alternateColor};}
.btnOutlineStyle.btnAlternateColor,.btnFilledStyle.btnAlternateColor:hover{border:2px solid {$alternateColor};color:{$alternateColor};}
.btnOutlineStyle.btnAlternateColor span,.btnFilledStyle.btnAlternateColor:hover span,.btnOutlineStyle.btnAlternateColor span:before,.btnFilledStyle.btnAlternateColor:hover span:before,.btnOutlineStyle.btnAlternateColor a,.btnFilledStyle.btnAlternateColor:hover a,.btnOutlineStyle.btnAlternateColor .btIco a:before,.btnFilledStyle.btnAlternateColor:hover .btIco a:before,.btnOutlineStyle.btnAlternateColor button,.btnFilledStyle.btnAlternateColor:hover button{color:{$alternateColor}!important;}
.btnBorderlessStyle.btnAlternateColor span,.btnBorderlessStyle.btnAlternateColor span:before,.btnBorderlessStyle.btnAlternateColor a,.btnBorderlessStyle.btnAlternateColor .btIco a:before,.btnBorderlessStyle.btnAlternateColor button{color:{$alternateColor};}
.btCounterHolder{font-family:\"{$headingFont}\";}
.btCounterHolder .btCountdownHolder .days_text,.btCounterHolder .btCountdownHolder .hours_text,.btCounterHolder .btCountdownHolder .minutes_text,.btCounterHolder .btCountdownHolder .seconds_text{color:{$accentColor};}
.btPriceTable .btPriceTableHeader{background:{$accentColor};}
.btPriceTableSticker{font-family:\"{$headingFont}\";}
.header .btSuperTitle{font-family:\"{$headingSuperTitleFont}\";}
.header .btSubTitle{font-family:\"{$headingSubTitleFont}\";}
.btGridContent .header .btSuperTitle a:hover{color:{$accentColor};}
.btCatFilter .btCatFilterItem:hover{color:{$accentColor};}
.btCatFilter .btCatFilterItem.active{color:{$accentColor};}
h4.nbs a .nbsItem .nbsDir{font-family:\"{$headingSuperTitleFont}\";}
.btInfoBar .btInfoBarMeta p strong{color:{$accentColor};}
.recentTweets small:before{color:{$accentColor};}
.tabsHeader li{font-family:\"{$headingFont}\";}
.tabsVertical .tabAccordionTitle{font-family:\"{$headingFont}\";}
.btAnimNav li.btAnimNavDot{font-family:{$headingFont};}
.btAnimNav li.btAnimNavNext:hover,.btAnimNav li.btAnimNavPrev:hover{border-color:{$accentColor};color:{$accentColor};}
p.demo_store{background-color:{$accentColor};}
.woocommerce .woocommerce-info a: not(.button),.woocommerce .woocommerce-message a: not(.button),.woocommerce-page .woocommerce-info a: not(.button),.woocommerce-page .woocommerce-message a: not(.button){color:{$accentColor};}
.woocommerce .woocommerce-message:before,.woocommerce .woocommerce-info:before,.woocommerce-page .woocommerce-message:before,.woocommerce-page .woocommerce-info:before{color:{$accentColor};}
.woocommerce p.lost_password:before,.woocommerce-page p.lost_password:before{color:{$accentColor};}
.woocommerce form.login p.lost_password a:hover,.woocommerce-page form.login p.lost_password a:hover{color:{$accentColor};}
.woocommerce .added:after,.woocommerce .loading:after,.woocommerce-page .added:after,.woocommerce-page .loading:after{background-color:{$accentColor};}
.woocommerce div.product .stock,.woocommerce-page div.product .stock{color:{$accentColor};}
.woocommerce div.product a.reset_variations:hover,.woocommerce-page div.product a.reset_variations:hover{color:{$accentColor};}
.woocommerce .products ul li.product .btPriceTableSticker,.woocommerce ul.products li.product .btPriceTableSticker,.woocommerce-page .products ul li.product .btPriceTableSticker,.woocommerce-page ul.products li.product .btPriceTableSticker{background:{$accentColor};}
.woocommerce nav.woocommerce-pagination ul li a:focus,.woocommerce nav.woocommerce-pagination ul li a:hover,.woocommerce nav.woocommerce-pagination ul li a.next,.woocommerce nav.woocommerce-pagination ul li a.prev,.woocommerce nav.woocommerce-pagination ul li span.current,.woocommerce-page nav.woocommerce-pagination ul li a:focus,.woocommerce-page nav.woocommerce-pagination ul li a:hover,.woocommerce-page nav.woocommerce-pagination ul li a.next,.woocommerce-page nav.woocommerce-pagination ul li a.prev,.woocommerce-page nav.woocommerce-pagination ul li span.current{background:{$accentColor};}
.woocommerce .star-rating span:before,.woocommerce-page .star-rating span:before{color:{$accentColor};}
.woocommerce p.stars a[class^=\"star-\"].active:after,.woocommerce p.stars a[class^=\"star-\"]:hover:after,.woocommerce-page p.stars a[class^=\"star-\"].active:after,.woocommerce-page p.stars a[class^=\"star-\"]:hover:after{color:{$accentColor};}
.woocommerce-cart table.cart td.product-remove a.remove{color:{$accentColor};border:1px solid {$accentColor};}
.woocommerce-cart table.cart td.product-remove a.remove:hover{background-color:{$accentColor};}
.woocommerce-cart .cart_totals .discount td{color:{$accentColor};}
.woocommerce-account header.title .edit{color:{$accentColor};}
.woocommerce-account header.title .edit:before{color:{$accentColor};}
.btLightSkin.woocommerce-page .product .headline a:hover,.btDarkSkin .btLightSkin.woocommerce-page .product .headline a:hover,.btDarkSkin.woocommerce-page .product .headline a:hover,.btLightSkin .btDarkSkin.woocommerce-page .product .headline a:hover{color:{$accentColor};}
.btQuoteBooking .btContactNext{border:{$accentColor} 2px solid;color:{$accentColor};}
.btQuoteBooking .btContactNext:hover,.btQuoteBooking .btContactNext:active{background-color:{$accentColor}!important;}
.btQuoteBooking .btQuoteSwitch:hover{-webkit-box-shadow:0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);box-shadow:0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);}
.btQuoteBooking .btQuoteSwitch.on .btQuoteSwitchInner{background:{$accentColor};}
.btQuoteBooking .dd.ddcommon.borderRadiusTp .ddTitleText,.btQuoteBooking .dd.ddcommon.borderRadiusBtm .ddTitleText{-webkit-box-shadow:5px 0 0 {$accentColor} inset,0 2px 10px rgba(0,0,0,.2);box-shadow:5px 0 0 {$accentColor} inset,0 2px 10px rgba(0,0,0,.2);}
.btQuoteBooking .ui-slider .ui-slider-handle{background:{$accentColor};}
.btQuoteBooking .btQuoteBookingForm .btQuoteTotal{background:{$accentColor};}
.btQuoteBooking .btContactFieldMandatory.btContactFieldError input,.btQuoteBooking .btContactFieldMandatory.btContactFieldError textarea{border:1px solid {$accentColor};-webkit-box-shadow:0 0 0 1px {$accentColor} inset;box-shadow:0 0 0 1px {$accentColor} inset;}
.btQuoteBooking .btContactFieldMandatory.btContactFieldError .dd.ddcommon.borderRadius .ddTitleText{border:1px solid {$accentColor};-webkit-box-shadow:0 0 0 1px {$accentColor} inset;box-shadow:0 0 0 1px {$accentColor} inset;}
.btQuoteBooking .btContactFieldMandatory.btContactFieldError input:hover,.btQuoteBooking .btContactFieldMandatory.btContactFieldError textarea:hover{-webkit-box-shadow:0 0 0 1px {$accentColor} inset,0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);box-shadow:0 0 0 1px {$accentColor} inset,0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);}
.btQuoteBooking .btContactFieldMandatory.btContactFieldError .dd.ddcommon.borderRadius:hover .ddTitleText{-webkit-box-shadow:0 0 0 1px {$accentColor} inset,0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);box-shadow:0 0 0 1px {$accentColor} inset,0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);}
.btQuoteBooking .btContactFieldMandatory.btContactFieldError input:focus,.btQuoteBooking .btContactFieldMandatory.btContactFieldError textarea:focus{-webkit-box-shadow:0 0 0 1px {$accentColor} inset,5px 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);box-shadow:0 0 0 1px {$accentColor} inset,5px 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);}
.btQuoteBooking .btContactFieldMandatory.btContactFieldError .dd.ddcommon.borderRadiusTp .ddTitleText{-webkit-box-shadow:0 0 0 1px {$accentColor} inset,5px 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);box-shadow:0 0 0 1px {$accentColor} inset,5px 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);}
.btQuoteBooking .btSubmitMessage{color:{$accentColor};}
.btDatePicker .ui-datepicker-header{background-color:{$accentColor};}
.btQuoteBooking .btContactSubmit{background-color:{$accentColor};border:2px solid {$accentColor};}
.btQuoteBooking .btContactSubmit:hover{color:{$accentColor};}
.btPayPalButton:hover{-webkit-box-shadow:0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);box-shadow:0 0 0 {$accentColor} inset,0 1px 5px rgba(0,0,0,.2);}
", array() );