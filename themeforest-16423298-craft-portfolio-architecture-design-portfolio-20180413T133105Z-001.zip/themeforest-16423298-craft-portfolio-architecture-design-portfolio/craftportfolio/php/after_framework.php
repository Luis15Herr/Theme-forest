<?php

// OVERLAY LINES

BoldThemes_Customize_Default::$data['overlay_lines'] = '0';
BoldThemes_Customize_Default::$data['buttons_shape'] = 'btSquareButtons';

if ( ! function_exists( 'boldthemes_customize_overlay_lines' ) ) {
	function boldthemes_customize_overlay_lines( $wp_customize ) {
		
		$wp_customize->add_setting( BoldThemesFramework::$pfx . '_theme_options[overlay_lines]', array(
			'default'           => BoldThemes_Customize_Default::$data['overlay_lines'],
			'type'              => 'option',
			'capability'        => 'edit_theme_options',
			'sanitize_callback' => 'sanitize_text_field'
		));
		$wp_customize->add_control( 'overlay_lines', array(
			'label'     => esc_html__( 'Overlay Grid Lines', 'craftportfolio' ),
			'section'   => BoldThemesFramework::$pfx . '_general_section',
			'settings'  => BoldThemesFramework::$pfx . '_theme_options[overlay_lines]',
			'priority'  => 95,
			'type'      => 'select',
			'choices'   => array(
				'0' => esc_html__( 'No lines', 'craftportfolio' ),
				'1' => esc_html__( '1 column', 'craftportfolio' ),
				'2' => esc_html__( '2 columns', 'craftportfolio' ),
				'3' => esc_html__( '3 columns', 'craftportfolio' ),
				'4' => esc_html__( '4 columns', 'craftportfolio' ),
				'6' => esc_html__( '6 columns', 'craftportfolio' )
			)
		));
	}
}
add_action( 'customize_register', 'boldthemes_customize_overlay_lines' );

boldthemes_remove_customize_setting( 'header_style' );
boldthemes_remove_customize_setting( 'page_width' );
